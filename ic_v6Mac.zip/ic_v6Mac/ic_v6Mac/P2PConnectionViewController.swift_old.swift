//
//  P2PConnectionViewController.swift
//  ic_v6Mac
//
//  Created by Shabnam Suresh on 2016-05-04.
//  Copyright © 2016 Shabnam Suresh. All rights reserved.
//

import Cocoa
import MultipeerConnectivity
/*
//Multi Peer connectivity Variables
var peerID: MCPeerID!
var mcSession: MCSession!
var mcAdvertiserAssistant: MCAdvertiserAssistant!

//Function to communicate with MAC
func sendMesg()
{
    
    if mcSession.connectedPeers.count > 0 {
        // 2
        if !messg.isEmpty {
            // 3
            do {
                try mcSession.sendData(messg.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)!, toPeers: mcSession.connectedPeers, withMode: MCSessionSendDataMode.Reliable)
                print("###Message sent = \(messg)")
            } catch let error as NSError {
                
                print("error=\(error)")
                /*let ac = UIAlertController(title: "Send error", message: error.localizedDescription, preferredStyle: .Alert)
                 ac.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
                 presentViewController(ac, animated: true, completion: nil)*/
            }
            
        }
    }
}

*/
class P2PConnectionViewController: NSViewController, MCSessionDelegate, MCBrowserViewControllerDelegate{

    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        peerID = MCPeerID(displayName: NSHost.currentHost().localizedName!)
        mcSession = MCSession(peer: peerID, securityIdentity: nil, encryptionPreference: .Required)
        mcSession.delegate = self
    
       
    
        // Do view setup here.
    }

    func session(session: MCSession, didReceiveStream stream: NSInputStream, withName streamName: String, fromPeer peerID: MCPeerID)
    {
    
    }
    
    func session(session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, withProgress progress: NSProgress)
    {
    
    }
    
    func session(session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, atURL localURL: NSURL, withError error: NSError?)
    {
    
    }
    
    func browserViewControllerDidFinish(browserViewController: MCBrowserViewController)
    {
        //dismissViewControllerAnimated(true, completion: nil)
        self.dismissController(self)
    }
    
    func browserViewControllerWasCancelled(browserViewController: MCBrowserViewController)
    {
        //dismissViewControllerAnimated(true, completion: nil)
        self.dismissController(self)
    }
    
    //clients connect or disconnect
    func session(session: MCSession, peer peerID: MCPeerID, didChangeState state: MCSessionState)
    {
        switch state {
            case MCSessionState.Connected:
            print("Connected: \(peerID.displayName)")
    
            case MCSessionState.Connecting:
            print("Connecting: \(peerID.displayName)")
    
            case MCSessionState.NotConnected:
            print("Not Connected: \(peerID.displayName)")
        }
    }
    
    @IBAction func HostSession(sender: AnyObject) {
        print("Session Hosted")
        mcAdvertiserAssistant = MCAdvertiserAssistant(serviceType: "ic-v5", discoveryInfo: nil, session: mcSession)
        mcAdvertiserAssistant.start()
        self.dismissController(self)
    }
    
    
    @IBAction func JoinSessionPopup(sender: AnyObject) {
        let mcBrowser = MCBrowserViewController(serviceType: "ic-v5", session: mcSession)
        mcBrowser.delegate = self
        presentViewController(mcBrowser, asPopoverRelativeToRect: sender.frame, ofView: sender as! NSView, preferredEdge: NSRectEdge.MinX, behavior: NSPopoverBehavior.Transient)
    }
    
    
    //To receive that on the other side
    func session(session: MCSession, didReceiveData data: NSData, fromPeer peerID: MCPeerID)
    {
        print("Inside here #####")
        if let str = NSString(data: data, encoding: NSUTF8StringEncoding)
        {
            dispatch_async(dispatch_get_main_queue())
            { [unowned self] in
                print("############ str=\(str)")
                //self.ipadBtnlbl.text = str as String
                //self.log.info("String from iPAD \(str)")
                //self.ipadStatus = str as String
                //self.setScreen()
            }
        }
    }

}
