//
//  SetupViewController.swift
//  ic_v6Mac
//
//  Created by Shabnam Suresh on 2016-05-08.
//  Copyright © 2016 Shabnam Suresh. All rights reserved.
//

import Cocoa

class SetupViewController: NSViewController {

    var path : NSURL! = nil
    var agPath : NSURL! = nil
    var prevideoPath : NSURL! = nil
    var leftvideoPath : NSURL! = nil
    var rightvideoPath : NSURL! = nil
    var leftImgPath : NSURL! = nil
    var rightImgPath : NSURL! = nil
    var leftImg : NSImage! = nil
    var rightImg : NSImage! = nil
    
    //Labels
    @IBOutlet weak var sessionNamelbl: NSTextField!
    @IBOutlet weak var studyNamelbl: NSTextField!
    @IBOutlet weak var subjectIdlbl: NSTextField!
    @IBOutlet weak var genderlbl: NSTextField!
    @IBOutlet weak var agelbl: NSTextField!
    @IBOutlet weak var expNamelbl: NSTextField!
    @IBOutlet weak var coderNamelbl: NSTextField!
    @IBOutlet weak var commentslbl: NSTextField!
    @IBOutlet weak var datelbl: NSTextField!
    @IBOutlet weak var agFilePathlbl: NSTextField!
    @IBOutlet weak var prevideoFilePathlbl: NSTextField!
    @IBOutlet weak var leftvideoFilePathlbl: NSTextField!
    @IBOutlet weak var rightvideoFilePathlbl: NSTextField!
    @IBOutlet weak var leftImgFilePathlbl: NSTextField!
    @IBOutlet weak var rightImgFilePathlbl: NSTextField!
    
    //Text Fields
    
    @IBOutlet weak var sessionNametxtfld: NSTextField!
    @IBOutlet weak var studyNametxtfld: NSTextField!
    @IBOutlet weak var subjectIdtxtfld: NSTextField!
    
    @IBOutlet weak var agetxtfld: NSTextField!
    @IBOutlet weak var gendertxtfld: NSTextField!
       
    @IBOutlet weak var expNametxtfld: NSTextField!
    @IBOutlet weak var coderNametxtfld: NSTextField!
    
    @IBOutlet weak var commentstxtfld: NSTextField!
    @IBOutlet weak var datetxtfld: NSTextField!
    
    @IBOutlet weak var attnGrabberFilePathtxtfld: NSTextField!
    @IBOutlet weak var preVideoFilePathtxtfld: NSTextField!
    @IBOutlet weak var leftVideoFilePathtxtfld: NSTextField!
    @IBOutlet weak var rightVideoFilePathtxtfld: NSTextField!
    
    @IBOutlet weak var leftImageFilePathtxtfld: NSTextField!
    @IBOutlet weak var leftImgHolderView: NSImageView!
    @IBOutlet weak var rightImageFilePathtxtfld: NSTextField!
    @IBOutlet weak var rightImgHolderView: NSImageView!
    
    
    //Buttons
    @IBOutlet weak var attnGrabberPathBtn: NSButton!
    @IBOutlet weak var preVideoPathBtn: NSButton!
    @IBOutlet weak var leftVideoPathBtn: NSButton!
    @IBOutlet weak var rightVideoPathBtn: NSButton!
    
    @IBOutlet weak var cancelBtn: NSButton!
    @IBOutlet weak var submitBtn: NSButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here
        
        //Load previously submitted values
        loadValues()
        
        //Disable all the Path fields
        datetxtfld.enabled = false
        setupInfoObject.setCurrentDate()
        datetxtfld.stringValue = setupInfoObject.getCurrentDate()
        
        attnGrabberFilePathtxtfld.enabled = false
        preVideoFilePathtxtfld.enabled = false
        leftVideoFilePathtxtfld.enabled = false
        rightVideoFilePathtxtfld.enabled = false
        leftImageFilePathtxtfld.enabled = false
        rightImageFilePathtxtfld.enabled = false
        
    }
    
    @IBAction func attnGrabberPathBtnTapped(sender: AnyObject) {
        openFile()
        if(path != nil){
            agPath = path!
            attnGrabberFilePathtxtfld.stringValue = "\(path!)"
        }
    }
    
    @IBAction func preVideoPathBtnTapped(sender: AnyObject) {
        openFile()
        if(path != nil){
            prevideoPath = path!
            preVideoFilePathtxtfld.stringValue = "\(path!)"
        }
    }
    
    @IBAction func rightVideoPathBtnTapped(sender: AnyObject) {
        openFile()
        if(path != nil){
            rightvideoPath = path!
            rightVideoFilePathtxtfld.stringValue = "\(path!)"
        }
    }
    
    @IBAction func leftVideoPathBtnTapped(sender: AnyObject) {
        openFile()
        if(path != nil){
            leftvideoPath = path!
            leftVideoFilePathtxtfld.stringValue = "\(path!)"
        }
    }
    
    @IBAction func leftImagePathBtnTapped(sender: AnyObject) {
        openFile()
        if(path != nil){
            //Set the Image View
            let data = NSData(contentsOfURL: path!) //make sure your image in this url does exist
            leftImgHolderView.image = NSImage(data: data!)
            leftImgPath = path!
            leftImg = NSImage(data: data!)
            leftImageFilePathtxtfld.stringValue = "\(path!)"
            
            //Var set to false everytime the image is changed
            leftImageSentToIPad = false
        }
    }
    
    @IBAction func rightImagePathBtnTapped(sender: AnyObject) {
        openFile()
        if(path != nil){
            //Set the Image View
            let data = NSData(contentsOfURL: path!) //make sure your image in this url does exist           
            rightImgHolderView.image = NSImage(data: data!)
            rightImgPath = path!
            rightImg = NSImage(data: data!)
            rightImageFilePathtxtfld.stringValue = "\(path!)"
            
            //Var set to false everytime the image is changed
            rightImageSentToIPad = false
            
        }

    }
    
    func openFile()
    {
        let dialog = NSOpenPanel();
        
        dialog.allowsMultipleSelection = false
        
        if (dialog.runModal() == NSModalResponseOK) {
            let result = dialog.URL?.filePathURL // Pathname of the file
            
            print("Result = \(result)")
            if (result != nil) {
                path = result!
            }
        } else {
            // User clicked on "Cancel"
            print("User clicked on Cancel")
            return
        }
        
        
        
    }
    
    @IBAction func CancelBtnTapped(sender: AnyObject) {
        self.dismissController(self)
        
    }
    
    @IBAction func SubmitBtnTapped(sender: AnyObject) {
       if(checkForm())
       {
            //Set the values
            setupInfoObject.setSessionNetworkName(sessionNametxtfld.stringValue)
            setupInfoObject.setStudyExpName(studyNametxtfld.stringValue)
            setupInfoObject.setSubjectID(subjectIdtxtfld.stringValue)
        
            setupInfoObject.setSubjectGender(gendertxtfld.stringValue)
            setupInfoObject.setSubjectAge(agetxtfld.stringValue)
            setupInfoObject.setExperimenterName(expNametxtfld.stringValue)
            setupInfoObject.setCodersName(coderNametxtfld.stringValue)
        
            setupInfoObject.setSplComments(commentstxtfld.stringValue)
            //setupInfoObject.setCurrentDate()
        
        
            //set the global File URLs
            if(agPath != nil)
            {
                setupInfoObject.setAttnGrabberFilepath(agPath)
                agFileURL = agPath
            }
            if(prevideoPath != nil)
            {
                setupInfoObject.setPreVideoFilepath(prevideoPath)
                prevideoFileURL = prevideoPath
            }
            if(leftvideoPath != nil)
            {
                setupInfoObject.setLeftVideoFilepath(leftvideoPath)
                leftvideoFileURL = leftvideoPath
            }
            if(rightvideoPath != nil)
            {
                setupInfoObject.setRightVideoFilepath(rightvideoPath)
                rightvideoFileURL = rightvideoPath
            }
            if(leftImgPath != nil)
            {
                setupInfoObject.setLeftImgFilepath(leftImgPath)
                setupInfoObject.setLeftBtnImage(leftImg)
                leftImgFileURL = leftImgPath
                leftImage = leftImg
            }
            if(rightImgPath != nil)
            {
                setupInfoObject.setRightImgFilepath(rightImgPath)
                setupInfoObject.setRightBtnImage(rightImg)
                rightImgFileURL = rightImgPath
                rightImage = rightImg
            }
        
            //Write saved values into the log
        
            log.info(" *************************** Setup Information *************************** ")
            log.info("Session Name :\(sessionNametxtfld.stringValue)")
            log.info("Study Name :\(studyNametxtfld.stringValue)")
            log.info("Subject ID :\(subjectIdtxtfld.stringValue)")
        
            log.info("Gender :\(gendertxtfld.stringValue)")
            log.info("Age :\(agetxtfld.stringValue)")
            log.info("Experimenter's Name :\(expNametxtfld.stringValue)")
            log.info("Coder's Name :\(coderNametxtfld.stringValue)")
        
            log.info("Log Filename :\(commentstxtfld.stringValue)")
            log.info("Date :\(datetxtfld.stringValue)")
        
            log.info("Attention Grabber video file URL :\(attnGrabberFilePathtxtfld.stringValue)")
            log.info("Prevideo file URL :\(preVideoFilePathtxtfld.stringValue)")
            log.info("Left Button video file URL :\(leftVideoFilePathtxtfld.stringValue)")
            log.info("Right Button video file URL :\(rightVideoFilePathtxtfld.stringValue)")
            log.info("Left Button image file URL :\(leftImageFilePathtxtfld.stringValue)")
            log.info("Right Button image file URL :\(rightImageFilePathtxtfld.stringValue)")
            log.info(" *************************** Setup Information *************************** ")
        
            //Show Success Alert
        
            let ac: NSAlert = NSAlert()
            ac.messageText = "Success"
            ac.informativeText = "Setup Information is submitted. Make sure to click the 'Send Images' Button to send the images to the iPAD"
            ac.alertStyle = NSAlertStyle.InformationalAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            // Variable that keeps track at least form has been submitted once
            setupInfoEntered = true
        
            let mainVC = NSApplication.sharedApplication().mainWindow?.contentViewController as? ViewController
            mainVC?.readyScreen()
        
            self.dismissController(self)
        
        }
        
    }
    
    func loadValues()
    {
        if(setupInfoObject.sessionName != nil)
        {
            sessionNametxtfld.stringValue = setupInfoObject.getSessionNetworkName()
        }
        
        if(setupInfoObject.studyName != nil)
        {
            studyNametxtfld.stringValue = setupInfoObject.getStudyExpName()
        }
        
        if(setupInfoObject.subjectId != nil)
        {
            subjectIdtxtfld.stringValue = setupInfoObject.getSubjectID()
        }
        
        if(setupInfoObject.gender != nil)
        {
            gendertxtfld.stringValue = setupInfoObject.getSubjectGender()
        }
        
        if(setupInfoObject.age != nil)
        {
            agetxtfld.stringValue = setupInfoObject.getSubjectAge()
        }
        
        if(setupInfoObject.expName != nil)
        {
            expNametxtfld.stringValue = setupInfoObject.getExperimenterName()
        }
        
        if(setupInfoObject.coderName != nil)
        {
            coderNametxtfld.stringValue = setupInfoObject.getCodersName()
        }
        
        if(setupInfoObject.comments != nil)
        {
            commentstxtfld.stringValue = setupInfoObject.getSplComments()
        }
        
        if(setupInfoObject.attnGrabberFilePath != nil)
        {
            attnGrabberFilePathtxtfld.stringValue = "\(setupInfoObject.getAttnGrabberFilepath())"
        }
        
        if(setupInfoObject.preVideoFilePath != nil)
        {
            preVideoFilePathtxtfld.stringValue = "\(setupInfoObject.getPreVideoFilepath())"
        }
        
        if(setupInfoObject.leftVideoFilePath != nil)
        {
            leftVideoFilePathtxtfld.stringValue = "\(setupInfoObject.getLeftVideoFilepath())"
        }
        
        if(setupInfoObject.rightVideoFilePath != nil)
        {
            rightVideoFilePathtxtfld.stringValue = "\(setupInfoObject.getRightVideoFilepath())"
        }
        if(setupInfoObject.leftImgFilePath != nil)
        {
            leftImageFilePathtxtfld.stringValue = "\(setupInfoObject.getLeftImgFilepath())"
        }
        if(setupInfoObject.rightImgFilePath != nil)
        {
            rightImageFilePathtxtfld.stringValue = "\(setupInfoObject.getRightImgFilepath())"
        }
        if(setupInfoObject.leftBtnImg != nil)
        {
             leftImgHolderView.image =  setupInfoObject.getLeftBtnImage()
        }
        
        if(setupInfoObject.rightBtnImg != nil)
        {
            rightImgHolderView.image = setupInfoObject.getRightBtnImage()
        }
        
    }
    
    func checkForm() -> Bool{
        
        if(sessionNametxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Session Name is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            sessionNamelbl.textColor = NSColor.redColor()
            sessionNametxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            sessionNamelbl.textColor = NSColor.blackColor()
        }
        
        if(studyNametxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Study Name is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            studyNamelbl.textColor = NSColor.redColor()
            studyNametxtfld.becomeFirstResponder()
            
            return false
        }
        else
        {
            studyNamelbl.textColor = NSColor.blackColor()
        }
        
        if(subjectIdtxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Subject's ID is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            subjectIdlbl.textColor = NSColor.redColor()
            subjectIdtxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            subjectIdlbl.textColor = NSColor.blackColor()
        }
        
        if(gendertxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Subject's Gender is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            genderlbl.textColor = NSColor.redColor()
            gendertxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            genderlbl.textColor = NSColor.blackColor()
        }
        
        if(agetxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Subject's Age is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            agelbl.textColor = NSColor.redColor()
            agetxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            agelbl.textColor = NSColor.blackColor()
        }
        
        if(expNametxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Experimenter's Name is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            expNamelbl.textColor = NSColor.redColor()
            expNametxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            expNamelbl.textColor = NSColor.blackColor()
        }
        
        if(coderNametxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Coder's Name is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            coderNamelbl.textColor = NSColor.redColor()
            coderNametxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            coderNamelbl.textColor = NSColor.blackColor()
        }
        
        if(commentstxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Log filename is Mandatory"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            commentslbl.textColor = NSColor.redColor()
            commentstxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            commentslbl.textColor = NSColor.blackColor()
        }
        
        if(attnGrabberFilePathtxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Attention Grabber Video path is not set"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            agFilePathlbl.textColor = NSColor.redColor()
            attnGrabberFilePathtxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            agFilePathlbl.textColor = NSColor.blackColor()
        }
        
        if(preVideoFilePathtxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Prevideo path is not set"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            prevideoFilePathlbl.textColor = NSColor.redColor()
            preVideoFilePathtxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            prevideoFilePathlbl.textColor = NSColor.blackColor()
        }
        
        if(leftVideoFilePathtxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Left video path is not set"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            leftvideoFilePathlbl.textColor = NSColor.redColor()
            leftVideoFilePathtxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            leftvideoFilePathlbl.textColor = NSColor.blackColor()
        }
        
        if(rightVideoFilePathtxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Right video path is not set"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            rightvideoFilePathlbl.textColor = NSColor.redColor()
            rightVideoFilePathtxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            rightvideoFilePathlbl.textColor = NSColor.blackColor()
        }
        
        if(leftImageFilePathtxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Left Button Image path is not set"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            leftImgFilePathlbl.textColor = NSColor.redColor()
            leftImageFilePathtxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            leftImgFilePathlbl.textColor = NSColor.blackColor()
        }
        
        
        if(rightImageFilePathtxtfld.stringValue == "")
        {
            let ac: NSAlert = NSAlert()
            ac.messageText = "Missing Information"
            ac.informativeText = "Right Button Image path is not set"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            ac.runModal()
            rightImgFilePathlbl.textColor = NSColor.redColor()
            rightImageFilePathtxtfld.becomeFirstResponder()
            return false
        }
        else
        {
            rightImgFilePathlbl.textColor = NSColor.blackColor()
        }

        
        return true
    }
    
}
