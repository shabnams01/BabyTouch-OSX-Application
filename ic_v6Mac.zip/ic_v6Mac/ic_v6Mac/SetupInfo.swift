//
//  SetupInfo.swift
//  ic_v6Mac
//
//  Created by Shabnam Suresh on 2016-05-08.
//  Copyright © 2016 Shabnam Suresh. All rights reserved.
//

import Cocoa

class SetupInfo: NSObject {
    
    var sessionName: String! = nil
    var studyName: String! = nil
    var subjectId: String! = nil
    
    var age: String! = nil
    var gender: String! = nil
    
    var expName: String! = nil
    var coderName: String! = nil
    
    var comments: String! = nil
    var date : String! = nil
    
    var attnGrabberFilePath: NSURL! = nil
    var preVideoFilePath: NSURL! = nil
    var leftVideoFilePath: NSURL! = nil
    var rightVideoFilePath: NSURL! = nil
    
    var leftImgFilePath:NSURL! = nil
    var leftBtnImg:NSImage! = nil
    var rightImgFilePath:NSURL! = nil
    var rightBtnImg:NSImage! = nil
    
    func getSessionNetworkName()-> String{
        return sessionName
    }
    
    func setSessionNetworkName(s : String){
        sessionName = s
    }

    func getStudyExpName()-> String{
        return studyName
    }
    
    func setStudyExpName(s : String){
        studyName = s
    }
    
    func getSubjectID()-> String{
        return subjectId
    }
    
    func setSubjectID(s : String){
        subjectId = s
    }

    
    func getSubjectAge()-> String{
        return age
    }
    
    func setSubjectAge(s : String){
        age = s
    }
    
    func getSubjectGender()-> String{
        return gender
    }
    
    func setSubjectGender(s : String){
        gender = s
    }

    
    func getExperimenterName()-> String{
        return expName
    }
    
    func setExperimenterName(s : String){
        expName = s
    }
    
    func getCodersName()-> String{
        return coderName
    }
    
    func setCodersName(s : String){
        coderName = s
    }

    func getSplComments()-> String{
        return comments
    }
    
    func setSplComments(s : String){
        comments = s
    }

    func getCurrentDate()-> String{
        return date
    }
    
    func setCurrentDate(){
        let tempdate:NSDate = NSDate()
        let dateFormatter:NSDateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
        let DateInFormat:String = dateFormatter.stringFromDate(tempdate)
        date = DateInFormat
        
    }

    func getAttnGrabberFilepath()-> NSURL{
        return attnGrabberFilePath
    }
    
    func setAttnGrabberFilepath(u : NSURL){
        attnGrabberFilePath = u
    }

    func getPreVideoFilepath()-> NSURL{
        return preVideoFilePath
    }
    
    func setPreVideoFilepath(u : NSURL){
        preVideoFilePath = u
    }

    func getLeftVideoFilepath()-> NSURL{
        return leftVideoFilePath
    }
    
    func setLeftVideoFilepath(u : NSURL){
        leftVideoFilePath = u
    }
    func getRightVideoFilepath()-> NSURL{
        return rightVideoFilePath
    }
    
    func setRightVideoFilepath(u : NSURL){
        rightVideoFilePath = u
    }
    
    
    func getLeftImgFilepath()-> NSURL{
        return leftImgFilePath
    }
    
    func setLeftImgFilepath(u : NSURL){
        leftImgFilePath = u
    }
    
    func getLeftBtnImage()-> NSImage{
        return leftBtnImg
    }
    
    func setLeftBtnImage(i : NSImage){
        leftBtnImg = i
    }
    
    func getRightImgFilepath()-> NSURL{
        return rightImgFilePath
    }
    
    func setRightImgFilepath(u : NSURL){
        rightImgFilePath = u
    }
    
    func getRightBtnImage()-> NSImage{
        return rightBtnImg
    }
    
    func setRightBtnImage(i : NSImage){
        rightBtnImg = i
    }


}
