//
//  AppDelegate.swift
//  ic_v6Mac
//
//  Created by Shabnam Suresh on 2016-01-23.
//  Copyright © 2016 Shabnam Suresh. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    let log = XCGLogger.defaultInstance()

    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
        
        let todaysDate:NSDate = NSDate()
        let dateFormatter:NSDateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
        let DateInFormat:String = dateFormatter.stringFromDate(todaysDate)
        
        let logfile = "Log_"+"\(DateInFormat)"+".txt"
        
        log.setup(.Debug, showLogLevel: true, showFileNames: true, showLineNumbers: true, showDate: true, writeToFile: "/Users/shabnam_suresh/Desktop/Log/\(logfile)")
        
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

