//
//  ButtonCounter.swift
//  ic_v5Mac
//
//  Created by Shabnam Suresh on 2015-12-29.
//  Copyright © 2015 Shabnam Suresh. All rights reserved.
//

import Cocoa

class ButtonCounter: NSObject {
    
    var maxCount = 10
    var currCount = 0
    var colorChage = false
    var warningReqd = false
    
    func updateCounter() -> Int{
        currCount += 1
        return currCount
    }
    
    func resetCounter() -> Int{
        currCount = 0
        return currCount
    }

    
    func getMaximumCounter() -> Int{
        return maxCount
    }

    func setMaximumCounter(value : Int){
        maxCount = value
    }
    
    func getCurrentCounter() -> Int{
        return currCount
    }
    
    func setCurrentCounter(value : Int){
        currCount = value
    }

    func getColorChangeFlag() -> Bool{
        return colorChage
    }
    
    func setColorChangeFlag(flag : Bool){
        colorChage = flag
    }
    
    func setWarning(flag : Bool) {
        warningReqd = flag
    }
    
    func getWarningFlag() -> Bool{
        return warningReqd
    }
    


}
