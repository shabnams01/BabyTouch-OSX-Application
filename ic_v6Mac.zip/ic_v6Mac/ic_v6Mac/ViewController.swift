//
//  ViewController.swift
//  ic_v6Mac
//
//  Created by Shabnam Suresh on 2016-01-23.
//  Copyright © 2016 Shabnam Suresh. All rights reserved.
//

import Cocoa
import MultipeerConnectivity

//Global variables can be accessed across files
var messg : String! = nil               // Variable that keeps track message that has to be sent to the iPAD

var fileURL : NSURL! = nil              // Variable that keeps track of current URL playing on the video player
var agFileURL : NSURL! = nil            // Variable that keeps track of attention grabber video URL
var prevideoFileURL : NSURL! = nil      // Variable that keeps track of pre video URL
var leftvideoFileURL : NSURL! = nil     // Variable that keeps track of left video URL
var rightvideoFileURL : NSURL! = nil    // Variable that keeps track of right video URL
var leftImgFileURL : NSURL! = nil       // Variable that keeps track of left image URL
var rightImgFileURL : NSURL! = nil      // Variable that keeps track of right image URL
var leftImage : NSImage! = nil          // Variable that keeps track of left image
var rightImage : NSImage! = nil         // Variable that keeps track of right image
var leftImageSentToIPad : Bool! = false          // Variable that keeps track of left image being sent to iPad
var rightImageSentToIPad : Bool! = false          // Variable that keeps track of right image being sent to iPad



var setupInfoEntered : Bool = false     // Variable that keeps track at least form has been submitted once

var buttonId : String! = "X"            // The button Id keepd track whether attention grabber button 
                                        // has been pressed or not AG: Attention Grabber X: All others

let log = XCGLogger.defaultInstance()

//Global Objects

var setupInfoObject = SetupInfo()

//3 Video player objects are created to keep track of 3 Players stacked on top of each other
// videoPlayerObject is used for playing all the normal videos
var videoPlayerObject = VideoPlayer()
// attnGrabberVideoPlayerObject is used for playing only attention grabbers the come into active mode only during the play time and then it is kept hidden
var attnGrabberVideoPlayerObject = VideoPlayer()
// emptyPlayerObject this object is created to show a black screen marking the end of the video so that the last frame is replayed by this
var emptyPlayerObject = VideoPlayer()
//Start up player View is created for helping the Experimenter to adjust the window size
var startupPlayerObject = VideoPlayer()


class ViewController: NSViewController, MCSessionDelegate, MCBrowserViewControllerDelegate, NSWindowDelegate {
    
    //Multi Peer connectivity Variables
    var peerID: MCPeerID!
    var mcSession: MCSession!
    var mcAdvertiserAssistant: MCAdvertiserAssistant!
    
    //List of Labels
    @IBOutlet weak var totTimelbl: NSTextField!
    @IBOutlet weak var currentStagelbl: NSTextField!
    
    @IBOutlet weak var currentActivitylbl: NSTextField!
    @IBOutlet weak var extDisplayStatuslbl: NSTextField!
   
    @IBOutlet weak var maxTimelbl: NSTextField!
    @IBOutlet weak var currTimelbl: NSTextField!
   
    
    @IBOutlet weak var countLeftBtnlbl: NSTextField!
    @IBOutlet weak var maxLeftBtnPresseslbl: NSTextField!
    @IBOutlet weak var countRightBtnlbl: NSTextField!
    @IBOutlet weak var maxRightBtnPresseslbl: NSTextField!
    
    @IBOutlet weak var ipadTotBtnPresseslbl: NSTextField!
    @IBOutlet weak var ipadBtnlbl: NSTextField!
    
    @IBOutlet weak var ipadConnectionStatuslbl: NSTextField!
    //List Of Buttons
    
    @IBOutlet weak var startbtn: NSButton!
    @IBOutlet weak var trainingbtn: NSButton!
    @IBOutlet weak var freeplaybtn: NSButton!
    @IBOutlet weak var finnishbtn: NSButton!
    
    
    @IBOutlet weak var startTotTimerbtn: NSButton!
    @IBOutlet weak var stopTotTimerbtn: NSButton!
    @IBOutlet weak var resetTotTimerbtn: NSButton!
    
    @IBOutlet weak var startCurrTimerbtn: NSButton!
    @IBOutlet weak var stopCurrTimerbtn: NSButton!
    @IBOutlet weak var resetCurrTimerbtn: NSButton!
    
    @IBOutlet weak var resetRightBtnCounterbtn: NSButton!
    @IBOutlet weak var resetLeftBtnCounterbtn: NSButton!
    
    @IBOutlet weak var externalDisplaybtn: NSButton!
    @IBOutlet weak var attnGrabberbtn: NSButton!
    @IBOutlet weak var prevideobtn: NSButton!
    @IBOutlet weak var leftvideobtn: NSButton!
    @IBOutlet weak var rightvideobtn: NSButton!
    @IBOutlet weak var pausebtn: NSButton!
    @IBOutlet weak var resumebtn: NSButton!
    @IBOutlet weak var flagbtn: NSButton!
    
   
    
    @IBOutlet weak var hostSessionbtn: NSButton!
    @IBOutlet weak var joinSessionbtn: NSButton!
    
    @IBOutlet weak var iPadTestConnectionbtn: NSButton!
    
    @IBOutlet weak var iPadAttnGrabberbtn: NSButton!
    @IBOutlet weak var iPadShowBothbtn: NSButton!
    @IBOutlet weak var iPadHidebtn: NSButton!
    @IBOutlet weak var iPadShowRightbtn: NSButton!
    @IBOutlet weak var iPadShowLeftbtn: NSButton!
    @IBOutlet weak var iPadSendImagesForBtns: NSButton!
    @IBOutlet weak var iPadSwapImagesOnBtns: NSButton!
    
    var ipadStatus = String()
    var firstTimeTraining = false
    
    //List of images to be sent to iPad
    //var listOfImgsToBeSentToIpad = [NSURL: Bool]()

   
    //Objects
    var totTimer = Timer()
    var currTimer = Timer()
    var leftBtnCounter = ButtonCounter()
    var rightBtnCounter = ButtonCounter()
    
    //Time conversion variables
    var currTimeHrs = 0
    var currTimeMins = 0
    var currTimeSecs = 0
    
    var totTimeHrs = 0
    var totTimeMins = 0
    var totTimeSecs = 0

    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.view.window?.delegate = self
        self.view.window?.title = "Infant Cognition"
        
        //peerID = MCPeerID(displayName: UIDevice.currentDevice().name)
        peerID = MCPeerID(displayName: NSHost.currentHost().localizedName!)
        mcSession = MCSession(peer: peerID, securityIdentity: nil, encryptionPreference: .Required)
        
        mcSession.delegate = self

        //Setting the startup Screen
        startbtn.enabled = false
        trainingbtn.enabled = false
        freeplaybtn.enabled = false
        finnishbtn.enabled = false
        
        startTotTimerbtn.enabled = false
        stopTotTimerbtn.enabled = false
        resetTotTimerbtn.enabled = false
        
        startCurrTimerbtn.enabled = false
        stopCurrTimerbtn.enabled = false
        resetCurrTimerbtn.enabled = false
        
        resetRightBtnCounterbtn.enabled = false
        resetLeftBtnCounterbtn.enabled = false
        
        externalDisplaybtn.enabled = false
        attnGrabberbtn.enabled = false
        prevideobtn.enabled = false
        leftvideobtn.enabled = false
        rightvideobtn.enabled = false
        pausebtn.enabled = false
        resumebtn.enabled = false
        flagbtn.enabled = false
        
        hostSessionbtn.enabled = false
        joinSessionbtn.enabled = false
        iPadTestConnectionbtn.enabled = false
        iPadAttnGrabberbtn.enabled = false
        iPadShowBothbtn.enabled = false
        iPadHidebtn.enabled = false
        iPadShowRightbtn.enabled = false
        iPadShowLeftbtn.enabled = false
        iPadSendImagesForBtns.enabled = false
        iPadSwapImagesOnBtns.enabled = false
        
        currentStagelbl.stringValue = "NIL"
        currentActivitylbl.stringValue = "Enter Experiment Setup Information"
        
        
        
    }
    
    
    //Close button on the window has been clicked
    func windowShouldClose(sender: AnyObject) -> Bool {
        // Exit Log Entry
        return true
    }
    
    func readyScreen() {
        
        //Enable the buttons only if the setup information has been entered correctly
        if(setupInfoEntered)
        {
            currentStagelbl.stringValue = "READY"
            currentActivitylbl.stringValue = "Setup Information all set"
            startbtn.enabled = true
            externalDisplaybtn.enabled = true
            hostSessionbtn.enabled = true
            joinSessionbtn.enabled = true
            
        
        }
    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
   
    
    @IBAction func StartBtnTapped(sender: NSButton) {
        log.info("******* Start the TRIAL *******")
        
        currentStagelbl.stringValue = "READY"
        currentActivitylbl.stringValue = "All values are reset"

        trainingbtn.enabled = true
        freeplaybtn.enabled = true
        finnishbtn.enabled = true
        
        buttonHighlight(startbtn,str: "Start", col: NSColor.blueColor())
        buttonHighlight(finnishbtn,str: "Finish", col: NSColor.blackColor())
        buttonHighlight(trainingbtn,str: "Training", col: NSColor.blackColor())
        buttonHighlight(freeplaybtn,str: "Freeplay", col: NSColor.blackColor())
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blackColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blackColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
        
        buttonHighlight(iPadAttnGrabberbtn,str: "Play Attention Grabber", col: NSColor.blackColor())
        buttonHighlight(iPadHidebtn,str: "Hide Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadShowLeftbtn,str: "Show Left Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowRightbtn,str: "Show Right Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowBothbtn,str: "Show Both Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadSwapImagesOnBtns,str: "Swap Images", col: NSColor.blackColor())
        buttonHighlight(iPadSendImagesForBtns,str: "Send Images", col: NSColor.blackColor())
        
        
        startTotTimerbtn.enabled = true
        stopTotTimerbtn.enabled = true
        resetTotTimerbtn.enabled = true
        
        startCurrTimerbtn.enabled = true
        stopCurrTimerbtn.enabled = true
        resetCurrTimerbtn.enabled = true
        
        resetRightBtnCounterbtn.enabled = true
        resetLeftBtnCounterbtn.enabled = true
        
        startbtn.enabled = true
        maxTimelbl.stringValue = "0"
        maxLeftBtnPresseslbl.stringValue = "0"
        maxRightBtnPresseslbl.stringValue = "0"
        ipadTotBtnPresseslbl.stringValue = "0"
        
        resetTotTimerbtn.performClick(self)
        resetCurrTimerbtn.performClick(self)
        resetLeftBtnCounterbtn.performClick(self)
        resetRightBtnCounterbtn.performClick(self)

        
        //To click the total elapsed start timer button
        startTotTimerbtn.performClick(self)
        
        ipadBtnlbl.stringValue = "NIL"
        
    }


    @IBAction func TrainingBtnTapped(sender: NSButton) {
        log.info("******* In the TRAINING *******")
        
        startbtn.enabled = true
        freeplaybtn.enabled = true
        finnishbtn.enabled = true
        
        currentStagelbl.stringValue = "TRAINING"
        currentActivitylbl.stringValue = "TRAINING Begins"
        
        buttonHighlight(trainingbtn,str: "Training", col: NSColor.blueColor())
        buttonHighlight(startbtn,str: "Restart", col: NSColor.blackColor())
        buttonHighlight(finnishbtn,str: "Finish", col: NSColor.blackColor())
        buttonHighlight(freeplaybtn,str: "Freeplay", col: NSColor.blackColor())
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blackColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blackColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
        
        buttonHighlight(iPadAttnGrabberbtn,str: "Play Attention Grabber", col: NSColor.blackColor())
        buttonHighlight(iPadHidebtn,str: "Hide Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadShowLeftbtn,str: "Show Left Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowRightbtn,str: "Show Right Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowBothbtn,str: "Show Both Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadSwapImagesOnBtns,str: "Swap Images", col: NSColor.blackColor())
        buttonHighlight(iPadSendImagesForBtns,str: "Send Images", col: NSColor.blackColor())
        
        startTotTimerbtn.enabled = true
        stopTotTimerbtn.enabled = true
        resetTotTimerbtn.enabled = true
        
        startCurrTimerbtn.enabled = true
        stopCurrTimerbtn.enabled = true
        resetCurrTimerbtn.enabled = true
        
        resetRightBtnCounterbtn.enabled = true
        resetLeftBtnCounterbtn.enabled = true
        
        
        freeplaybtn.enabled = true
        
        totTimer.setColorChangeFlag(false)
        
        currTimer.setColorChangeFlag(true)
        currTimer.setMaximumTime(20)
        maxTimelbl.stringValue = "\(currTimer.getMaximumTime())"
        
        leftBtnCounter.setMaximumCounter(2)
        maxLeftBtnPresseslbl.stringValue = "\(leftBtnCounter.getMaximumCounter())"
        leftBtnCounter.setColorChangeFlag(true)
        
        rightBtnCounter.setMaximumCounter(2)
        maxRightBtnPresseslbl.stringValue = "\(rightBtnCounter.getMaximumCounter())"
        rightBtnCounter.setColorChangeFlag(true)
        
        if firstTimeTraining {
           
            resetCurrTimerbtn.performClick(self)
            resetLeftBtnCounterbtn.performClick(self)
            resetRightBtnCounterbtn.performClick(self)
            
           ipadTotBtnPresseslbl.stringValue = "0"
            
        }
        else{
            startCurrTimerbtn.performClick(self)
            firstTimeTraining = true
        }
        ipadBtnlbl.stringValue = "No Button Pressed"
        
    }
    @IBAction func FreePlayBtnTapped(sender: NSButton) {
        log.info("******* In the FREE PLAY MODE*******")
        
        startbtn.enabled = true
        trainingbtn.enabled = true
        finnishbtn.enabled = true
        
        currentStagelbl.stringValue = "FREE PLAY"
        currentActivitylbl.stringValue = "FREE PLAY Begins"
        
        buttonHighlight(startbtn,str: "Restart", col: NSColor.blackColor())
        buttonHighlight(trainingbtn,str: "Training", col: NSColor.blackColor())
        buttonHighlight(freeplaybtn,str: "Freeplay", col: NSColor.blueColor())
        buttonHighlight(finnishbtn,str: "Finish", col: NSColor.blackColor())
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blackColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blackColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
        
        buttonHighlight(iPadAttnGrabberbtn,str: "Play Attention Grabber", col: NSColor.blackColor())
        buttonHighlight(iPadHidebtn,str: "Hide Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadShowLeftbtn,str: "Show Left Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowRightbtn,str: "Show Right Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowBothbtn,str: "Show Both Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadSwapImagesOnBtns,str: "Swap Images", col: NSColor.blackColor())
        buttonHighlight(iPadSendImagesForBtns,str: "Send Images", col: NSColor.blackColor())

        startTotTimerbtn.enabled = true
        stopTotTimerbtn.enabled = true
        resetTotTimerbtn.enabled = true
        
        startCurrTimerbtn.enabled = true
        stopCurrTimerbtn.enabled = true
        resetCurrTimerbtn.enabled = true
        
        resetRightBtnCounterbtn.enabled = true
        resetLeftBtnCounterbtn.enabled = true
        
        
        finnishbtn.enabled = true
        
        currentStagelbl.stringValue = "FREEPLAY"
        totTimer.setColorChangeFlag(false)
        
        currTimer.setColorChangeFlag(true)
        currTimer.setMaximumTime(50)
        maxTimelbl.stringValue = "\(currTimer.getMaximumTime())"
        
        leftBtnCounter.setMaximumCounter(5)
        maxLeftBtnPresseslbl.stringValue = "\(leftBtnCounter.getMaximumCounter())"
        leftBtnCounter.setColorChangeFlag(true)
        
        rightBtnCounter.setMaximumCounter(5)
        maxRightBtnPresseslbl.stringValue = "\(rightBtnCounter.getMaximumCounter())"
        rightBtnCounter.setColorChangeFlag(true)
        
        resetCurrTimerbtn.performClick(self)
        resetLeftBtnCounterbtn.performClick(self)
        resetRightBtnCounterbtn.performClick(self)
       
        ipadTotBtnPresseslbl.stringValue = "0"
        ipadBtnlbl.stringValue = "No Button Pressed"
    }
    
    @IBAction func FinishBtnTapped(sender: NSButton) {
        log.info("******* End of TRIAL *******")
        
        startbtn.enabled = true
        trainingbtn.enabled = false
        freeplaybtn.enabled = false
        
        currentStagelbl.stringValue = "END"
        currentActivitylbl.stringValue = "Trial Completed"
        
        buttonHighlight(finnishbtn,str: "Finish", col: NSColor.blueColor())
        buttonHighlight(startbtn,str: "Ready", col: NSColor.blackColor())
        buttonHighlight(trainingbtn,str: "Training", col: NSColor.blackColor())
        buttonHighlight(freeplaybtn,str: "Freeplay", col: NSColor.blackColor())
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blackColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blackColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
        
        buttonHighlight(iPadAttnGrabberbtn,str: "Play Attention Grabber", col: NSColor.blackColor())
        buttonHighlight(iPadHidebtn,str: "Hide Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadShowLeftbtn,str: "Show Left Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowRightbtn,str: "Show Right Button", col: NSColor.blackColor())
        buttonHighlight(iPadShowBothbtn,str: "Show Both Buttons", col: NSColor.blackColor())
        buttonHighlight(iPadSwapImagesOnBtns,str: "Swap Images", col: NSColor.blackColor())
        buttonHighlight(iPadSendImagesForBtns,str: "Send Images", col: NSColor.blackColor())
        
        startTotTimerbtn.enabled = false
        stopTotTimerbtn.enabled = false
        resetTotTimerbtn.enabled = false
        
        startCurrTimerbtn.enabled = false
        stopCurrTimerbtn.enabled = false
        resetCurrTimerbtn.enabled = false
        
        resetRightBtnCounterbtn.enabled = false
        resetLeftBtnCounterbtn.enabled = false
       
        
        startbtn.enabled = true
        maxTimelbl.stringValue = "0"
        maxLeftBtnPresseslbl.stringValue = "0"
        maxRightBtnPresseslbl.stringValue = "0"
        ipadTotBtnPresseslbl.stringValue = "0"
        
        totTimer.stopTimer()
        currTimer.stopTimer()
        
        resetLeftBtnCounterbtn.performClick(self)
        resetRightBtnCounterbtn.performClick(self)

    }
    
    
    @IBAction func StartTotTimerTapped(sender: NSButton) {
        totTimer.startTimer()
        
        var labelUpdateTimer = NSTimer()
        labelUpdateTimer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(ViewController.UpdateTimerTextLabel), userInfo: nil, repeats: true)
        
        log.info("Total Elapsed Timer Start Button Clicked")
        currentActivitylbl.stringValue = "Total Elapsed Timer started"

    }
    
    
    @IBAction func StopTotTimerTapped(sender: NSButton) {
        totTimer.stopTimer()
        log.info("Total Elapsed Timer Stop Button Clicked")
        currentActivitylbl.stringValue = "Total Elapsed Timer stopped"
        
        
        
        
    }
    
    @IBAction func ResetTotTimerTapped(sender: NSButton) {
        totTimer.resetTimer()
        totTimelbl.stringValue = "\(totTimer.getCurrentTime())"
        log.info("Total Elapsed Timer Reset Button Clicked")
        currentActivitylbl.stringValue = "Total Elapsed Timer reset"
        
        
    }
    
    @IBAction func StartCurrTimerTapped(sender: NSButton) {
        currTimer.startTimer()
        
        var labelUpdateTimer = NSTimer()
        labelUpdateTimer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(ViewController.UpdateTimerTextLabel), userInfo: nil, repeats: true)
        
        log.info("Current Stage Timer Start Button Clicked")
        currentActivitylbl.stringValue = "Current Stage Timer started"
        
        
    }
    
    @IBAction func StopCurrTimerTapped(sender: NSButton) {
        currTimer.stopTimer()
        
        log.info("Current Stage Timer Stop Button Clicked")
        currentActivitylbl.stringValue = "Current Stage Timer stopped"
        
        
    }
    
    @IBAction func ResetCurrTimerTapped(sender: NSButton) {
        currTimer.resetTimer()
        currTimelbl.stringValue = "\(currTimer.getCurrentTime())"
        
        log.info("Current Stage Timer Reset Button Clicked")
        currentActivitylbl.stringValue = "Current Stage Timer reset"
        
       
    }
    
    func UpdateTimerTextLabel(){
        
        
        let colorChangeFlgCurrTimer = currTimer.getColorChangeFlag()
        if colorChangeFlgCurrTimer{
            if (currTimer.getCurrentTime() < currTimer.getMaximumTime()){
                currTimelbl.textColor = NSColor.blueColor()
            }
            else
            {
                currTimelbl.textColor = NSColor.redColor()
            }
        }
        else
        {
            currTimelbl.textColor = NSColor.grayColor()
        }
        
        
        currTimeHrs = Int(currTimer.getCurrentTime() / 3600)
        currTimeMins = Int((currTimer.getCurrentTime() / 60) % 60)
        currTimeSecs = currTimer.getCurrentTime() % 60
        currTimelbl.stringValue = "\(currTimeHrs):\(currTimeMins):\(currTimeSecs)"
        
        
        totTimelbl.textColor = NSColor.grayColor()
        
        totTimeHrs = Int(totTimer.getCurrentTime() / 3600)
        totTimeMins = Int((totTimer.getCurrentTime() / 60) % 60)
        totTimeSecs = totTimer.getCurrentTime() % 60
        totTimelbl.stringValue = "\(totTimeHrs):\(totTimeMins):\(totTimeSecs)"
        
    }

    @IBAction func ResetLeftBtnCounterTapped(sender: NSButton) {
        leftBtnCounter.resetCounter()
        countLeftBtnlbl.stringValue = "\(leftBtnCounter.getCurrentCounter())"
        countLeftBtnlbl.textColor = NSColor.grayColor()
        maxLeftBtnPresseslbl.textColor = NSColor.grayColor()
        log.info("Reset Left Btn Counter Tapped")
        currentActivitylbl.stringValue = "Left Button Counter reset"
    }

    
    @IBAction func ResetRightBtnCounterTapped(sender: NSButton) {
        rightBtnCounter.resetCounter()
        countRightBtnlbl.stringValue = "\(rightBtnCounter.getCurrentCounter())"
        countRightBtnlbl.textColor = NSColor.grayColor()
        maxRightBtnPresseslbl.textColor = NSColor.grayColor()
        log.info("Reset Right Btn Counter Tapped")
        currentActivitylbl.stringValue = "Right Button Counter reset"
    }
    
    //To update the appearence of the Label when the values of Left and Right Button Counters are exceeded
    
    func UpdateBtnTextLabels(){
        
        
        let colorChangeFlgLeftBtn = leftBtnCounter.getColorChangeFlag()
        if colorChangeFlgLeftBtn{
            if (leftBtnCounter.getCurrentCounter() < leftBtnCounter.getMaximumCounter()){
                countLeftBtnlbl.textColor = NSColor.blueColor()
                maxLeftBtnPresseslbl.textColor = NSColor.blueColor()
            }
            else
            {
                countLeftBtnlbl.textColor = NSColor.redColor()
                maxLeftBtnPresseslbl.textColor = NSColor.redColor()
                log.info("Number of Left button pressed exceeded the set threshold value")
                currentActivitylbl.stringValue = "Left Button Value exceeded the set threshold value \(maxLeftBtnPresseslbl.stringValue)"
            }
        }
        else
        {
            countLeftBtnlbl.textColor = NSColor.grayColor()
            maxLeftBtnPresseslbl.textColor = NSColor.grayColor()
        }
        
        countLeftBtnlbl.stringValue = "\(leftBtnCounter.getCurrentCounter())"
        
        let colorChangeFlgRightBtn = rightBtnCounter.getColorChangeFlag()
        if colorChangeFlgRightBtn{
            if (rightBtnCounter.getCurrentCounter() < rightBtnCounter.getMaximumCounter()){
                countRightBtnlbl.textColor = NSColor.blueColor()
                maxRightBtnPresseslbl.textColor = NSColor.blueColor()
            }
            else
            {
                countRightBtnlbl.textColor = NSColor.redColor()
                maxRightBtnPresseslbl.textColor = NSColor.redColor()
                log.info("Number of Right button pressed exceeded the set threshold value")
                currentActivitylbl.stringValue = "Right Button Value exceeded the set threshold value \(maxLeftBtnPresseslbl.stringValue)"
            }
        }
        else
        {
            countRightBtnlbl.textColor = NSColor.grayColor()
            maxRightBtnPresseslbl.textColor = NSColor.grayColor()
        }
        
        countRightBtnlbl.stringValue = "\(rightBtnCounter.getCurrentCounter())"
        
        //Total no of Button pressed
        ipadTotBtnPresseslbl.stringValue = "\(rightBtnCounter.getCurrentCounter() + leftBtnCounter.getCurrentCounter())"
        
    }
    
    @IBAction func attnGrabberTapped(sender: NSButton) {
        messg = "Attention Grabber Playing"
        sendMesg()
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blueColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blackColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
        
        
        //fileURL = NSURL(fileURLWithPath:"/Users/shabnam_suresh/Desktop/videos/ExtScreenAG.mov")
        fileURL = agFileURL
        print(fileURL)
        
        currentActivitylbl.stringValue = "Play Attention Grabber on the External Display"
        extDisplayStatuslbl.stringValue = "Attention Grabber is Played"
        log.info("Attention Grabber is Played with File Name:\(fileURL) on external display")

        
        if(attnGrabberVideoPlayerObject.player != nil)
        {
            //Pause the main video player
            if(videoPlayerObject.player != nil)
            {
                startupPlayerObject.avplayerview.hidden = true
                videoPlayerObject.PauseVideo()
            }
            
            
            buttonId = "AG"
            attnGrabberVideoPlayerObject.avplayerview.hidden = false
            
            attnGrabberVideoPlayerObject.PlayVideo()
            
        }
        
    }
    
    @IBAction func prevideoTapped(sender: NSButton) {
        messg = "Pre Video Playing"
       sendMesg()
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blackColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blueColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
        
        //fileURL = NSURL(fileURLWithPath:"/Users/shabnam_suresh/Desktop/videos/prevideo.3gp")
        fileURL = prevideoFileURL
        print(fileURL)
        
        currentActivitylbl.stringValue = "Play Prevideo on the External Display"
        extDisplayStatuslbl.stringValue = "Prevideo is Played"
        log.info("Prevideo is Played with File Name:\(fileURL) on external display")

        
        if(videoPlayerObject.player != nil)
        {
            
            //Pause the attention grabber video player and hide the player
            //This case is when the user chooses to play the main video while attention grabber is being played
            
            if(startupPlayerObject.player != nil)
            {
                startupPlayerObject.PauseVideo()
                startupPlayerObject.avplayerview.hidden = true
            }

            if(attnGrabberVideoPlayerObject.player != nil)
            {
                attnGrabberVideoPlayerObject.PauseVideo()
                attnGrabberVideoPlayerObject.avplayerview.hidden = true
            }
            
            videoPlayerObject.PlayVideo()
        }

    }
    
    @IBAction func leftVidTapped(sender: NSButton) {
        messg = "Left Button Video Playing"
        sendMesg()
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blackColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blackColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blueColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
        
        //fileURL = NSURL(fileURLWithPath:"/Users/shabnam_suresh/Desktop/videos/leftvideo.3gp")
        fileURL = leftvideoFileURL
        print(fileURL)
        
        currentActivitylbl.stringValue = "Play Left Button video on the External Display"
        extDisplayStatuslbl.stringValue = "Left Button video is Played"
        log.info("Left Button video is Played with File Name:\(fileURL) on external display")
        
        if(videoPlayerObject.player != nil)
        {
            startupPlayerObject.avplayerview.hidden = true
            
            //Pause the attention grabber video player and hide the player
            //This case is when the user chooses to play the main video while attention grabber is being played
            if(attnGrabberVideoPlayerObject.player != nil)
            {
                attnGrabberVideoPlayerObject.PauseVideo()
                attnGrabberVideoPlayerObject.avplayerview.hidden = true
            }
            videoPlayerObject.PlayVideo()
        }

        leftBtnCounter.updateCounter()
        UpdateBtnTextLabels()
    }
    
    @IBAction func rightVidTapped(sender: NSButton) {
        messg = "Right Button Video Playing"
        sendMesg()
        
        buttonHighlight(attnGrabberbtn,str: "Attention Grabber for Display", col: NSColor.blackColor())
        buttonHighlight(prevideobtn,str: "Pre-video", col: NSColor.blackColor())
        buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
        buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blueColor())
        
        //fileURL = NSURL(fileURLWithPath:"/Users/shabnam_suresh/Desktop/videos/rightvideo.3gp")
        fileURL = rightvideoFileURL
        print(fileURL)
        
        currentActivitylbl.stringValue = "Play Right Button video on the External Display"
        extDisplayStatuslbl.stringValue = "Right Button video is Played"
        log.info("Right Button video is Played with File Name:\(fileURL) on external display")
        
        if(videoPlayerObject.player != nil)
        {
            startupPlayerObject.avplayerview.hidden = true
            
            //Pause the attention grabber video player and hide the player
            //This case is when the user chooses to play the main video while attention grabber is being played
            if(attnGrabberVideoPlayerObject.player != nil)
            {
                attnGrabberVideoPlayerObject.PauseVideo()
                attnGrabberVideoPlayerObject.avplayerview.hidden = true
            }
            videoPlayerObject.PlayVideo()
        }

        rightBtnCounter.updateCounter()
        UpdateBtnTextLabels()
    }

    @IBAction func resumeVideo(sender: AnyObject) {
        
        if(videoPlayerObject.player != nil)
        {
            videoPlayerObject.ResumeVideo()
        }
        
    }
    
    
    @IBAction func pauseVideo(sender: AnyObject) {
        
        if(videoPlayerObject.player != nil)
        {
            videoPlayerObject.PauseVideo()
        }
        
    }
    
    @IBAction func iPadAttentionGrabberTapped(sender: NSButton) {
        //Play Attention Grabber
        messg = "AG"
        sendMesg()
        
        currentActivitylbl.stringValue = "Play Attention Grabber on the iPAD"
        extDisplayStatuslbl.stringValue = "Attention Grabber is Played"
        log.info("Attention Grabber is Played with File Name:\(fileURL) on iPAD")
    }
    
    @IBAction func iPadShowBtnsTapped(sender: NSButton) {
        //Display buttons
        messg = "SB"
        sendMesg()
        ipadBtnlbl.stringValue = "No Button Pressed"
        
        currentActivitylbl.stringValue = "Show Buttons on the iPAD"
        log.info("Show Buttons on iPAD")
        
    }
    
    @IBAction func iPadHideBtnsTapped(sender: NSButton) {
        //Hide buttons
        messg = "HB"
        sendMesg()
        currentActivitylbl.stringValue = "Hide Buttons on the iPAD"
        log.info("Hide Buttons on iPAD")
    }
   
    @IBAction func iPadShowLeftBtnTapped(sender: AnyObject) {
        messg = "LB"
        sendMesg()
        currentActivitylbl.stringValue = "Show only Left button on iPAD"
        log.info("Show only Left button on iPAD")

    }
 
    @IBAction func iPadShowRightBtnTapped(sender: AnyObject) {
        messg = "RB"
        sendMesg()
        currentActivitylbl.stringValue = "Show only Right button on iPAD"
        log.info("Show only Right button on iPAD")
    }
    
    
    @IBAction func iPadSwapImagesOnBtnsTapped(sender: AnyObject) {
        messg = "Swap"
        sendMesg()
        currentActivitylbl.stringValue = "Swap the images on the iPad Buttons"
        log.info("Swap the images on the iPad Buttons")
        
        //swap images and their paths on the global variables
        let tempURL : NSURL! = leftImgFileURL
        leftImgFileURL = rightImgFileURL
        rightImgFileURL = tempURL
        
        let tempImg : NSImage! = leftImage
        leftImage = rightImage
        rightImage = tempImg
        
        if(leftImgFileURL != nil)
        {
            let strsplit = "\(leftImgFileURL!)".componentsSeparatedByString("/")
            messg = "SET-LB-\(strsplit.last!)"
            sendMesg()
            log.info("Left Button Image is changed to \(leftImgFileURL!) on the iPAD")
        }
        
        
        if(rightImgFileURL != nil)
        {
            let strsplit = "\(rightImgFileURL!)".componentsSeparatedByString("/")
            messg = "SET-RB-\(strsplit.last!)"
            sendMesg()
            log.info("Right Button Image is changed to \(rightImgFileURL!) on the iPAD")
        }

    }
    
    
    @IBAction func iPadSendImagesOnBtnsTapped(sender: AnyObject) {
        
        if(leftImageSentToIPad == false)
            {
                let strsplit = "\(leftImgFileURL!)".componentsSeparatedByString("/")
                print("Left button image name ::::: \(strsplit.last!)")

                messg = "LOAD-\(strsplit.last!)"
                sendMesg()
                sendImage(leftImage!)
                leftImageSentToIPad = true;
                messg = "SET-LB-\(strsplit.last!)"
                sendMesg()
                log.info("Left Button Image \(leftImgFileURL!) is sent to the iPAD")
            }
        
        
    
        if(rightImageSentToIPad == false)
        {
            let strsplit = "\(rightImgFileURL!)".componentsSeparatedByString("/")
            print("Right button image name ::::: \(strsplit.last!)")
    
            messg = "LOAD-\(strsplit.last!)"
            sendMesg()
            sendImage(rightImage!)
            rightImageSentToIPad = true;
            messg = "SET-RB-\(strsplit.last!)"
            sendMesg()
            log.info("Right Button Image \(rightImgFileURL!) is sent to the iPAD")

    
        }
        

    }

    
    //Fuction that gets called when Show External Display
    override func prepareForSegue(segue: NSStoryboardSegue, sender: AnyObject!) {
        
        if(segue.identifier == "extDisplaySegue")
        {
            enableExternalScreenBtns()
            externalDisplaybtn.enabled = false
            
           
            setScreen("X")
            
        }
    }
    
    //Function to disable the External Screen related Buttons
    func disableExternalScreenBtns(){
        
        externalDisplaybtn.enabled = true
        
        attnGrabberbtn.enabled = false
        prevideobtn.enabled = false
        leftvideobtn.enabled = false
        rightvideobtn.enabled = false
        pausebtn.enabled = false
        resumebtn.enabled = false
        flagbtn.enabled = false
    
        log.info("External Display Screen related Button Disabled")
        
    }
    
    //Function to enable the External Screen related Buttons
    func enableExternalScreenBtns(){
     
        attnGrabberbtn.enabled = true
        prevideobtn.enabled = true
        leftvideobtn.enabled = true
        rightvideobtn.enabled = true
        pausebtn.enabled = true
        resumebtn.enabled = true
        flagbtn.enabled = true
        
        log.info("External Display Screen related Button Enabled")
     }
    
    //Function to enable the iPad related Buttons
    func enableiPADBtns(){
        log.info("iPAD related Button Enabled")
        iPadHidebtn.enabled = true
        iPadShowBothbtn.enabled = true
        iPadAttnGrabberbtn.enabled = true
        iPadShowLeftbtn.enabled = true
        iPadShowRightbtn.enabled = true
        iPadTestConnectionbtn.enabled = true
        iPadSendImagesForBtns.enabled = true
        iPadSwapImagesOnBtns.enabled = true
    }
    
    //Function to disable the iPad related Buttons
    func disableiPADBtns(){
        log.info("iPAD related Button Disabled")
        iPadHidebtn.enabled = false
        iPadShowBothbtn.enabled = false
        iPadAttnGrabberbtn.enabled = false
        iPadShowLeftbtn.enabled = false
        iPadShowRightbtn.enabled = false
        iPadTestConnectionbtn.enabled = false
        iPadSendImagesForBtns.enabled = false
        iPadSwapImagesOnBtns.enabled = false

    }

  
    // This function is called when MAC receives messages from the iPAD
    func setScreen(str : String){
        
        ipadStatus = str
        
        if (ipadStatus == "Left Button")
        {
            log.info("iPAD recieved string 'Left Button'")
            buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.orangeColor())
            buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.blackColor())
            ipadBtnlbl.stringValue = str
        }
        else if (ipadStatus == "Right Button")
        {
            log.info("iPAD recieved string 'Right Button'")
            buttonHighlight(rightvideobtn,str: "Right Button Video", col: NSColor.orangeColor())
            buttonHighlight(leftvideobtn,str: "Left Button Video", col: NSColor.blackColor())
            ipadBtnlbl.stringValue = str
        }
        else if (ipadStatus == "Success")
        {
            ipadConnectionStatuslbl.stringValue = "Test Successful"
            ipadBtnlbl.stringValue = "iPAD and MAC are cuccessfully connected"
            log.info("Test Successful : iPAD and MAC are cuccessfully connected")
        }
        
        
    }
    
    //The funtion simply logs this below entry, 
    // the need for such a function is to give the experimenter a chance to cross check at a later point
    @IBAction func FlagTapped(sender: AnyObject) {
        log.info("IMPORTANT : There has been an occurrence where the buttons on the iPAD has been pressed simultaneously !!")
    }
    
    // Function responsible for highlighting effect
    func buttonHighlight(btn : NSButton , str : String , col: NSColor){
        
        let pstyle = NSMutableParagraphStyle()
        pstyle.alignment = .Center

        if(str != "X"){
            btn.attributedTitle = NSAttributedString(string: str, attributes: [ NSForegroundColorAttributeName : col, NSParagraphStyleAttributeName : pstyle ])
        }
    }
    
    //Function that is called when the Join Session Button is tapped
    @IBAction func StartHostingBtnTapped(sender: AnyObject) {
        
        enableiPADBtns()
        
        mcAdvertiserAssistant = MCAdvertiserAssistant(serviceType: "ic-v5", discoveryInfo: nil, session: mcSession)
        mcAdvertiserAssistant.start()
        
        log.info("Session Hosted by Mac")
    }
    
    //Function that is called when the Join Session Button is tapped
    @IBAction func JoinSessionBtnTapped(sender: AnyObject) {
        
        enableiPADBtns()
        
        let mcBrowser = MCBrowserViewController(serviceType: "ic-v5", session: mcSession)
        mcBrowser.delegate = self

        presentViewController(mcBrowser, asPopoverRelativeToRect: sender.frame, ofView: sender as! NSView, preferredEdge: NSRectEdge.MaxX, behavior: NSPopoverBehavior.Transient)
        
        log.info("Join a session Hosted by other Device")
        
    }
    @IBAction func TestConnection(sender: AnyObject) {
        messg = "Test"
        sendMesg()
        ipadBtnlbl.stringValue = "Test Connection with iPAD"
        log.info("Test Connection with iPAD")
    }
    
    // MPC Session Delegate to recieve continuous stream of Data like audio/video
    func session(session: MCSession, didReceiveStream stream: NSInputStream, withName streamName: String, fromPeer peerID: MCPeerID)
    {
    }
    
    // MPC Session Delegate to recieve images or files start function
    func session(session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, withProgress progress: NSProgress)
    {
    }

    // MPC Session Delegate to recieve images or files end function
    func session(session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, atURL localURL: NSURL, withError error: NSError?)
    {
    }
    
    //Funtion that is called when the Cancel button is clicked on MCBrowserViewController
    func browserViewControllerDidFinish(browserViewController: MCBrowserViewController)
    {
        print("Cancel Button clicked")
        browserViewController.dismissController(self)
    }
    
    //Funtion that is called when the Done button is clicked on MCBrowserViewController
    func browserViewControllerWasCancelled(browserViewController: MCBrowserViewController)
    {
        print("Done Button clicked")
        browserViewController.dismissController(self)
    }
    
    //clients connect or disconnect
    func session(session: MCSession, peer peerID: MCPeerID, didChangeState state: MCSessionState)
    {
        switch state {
        case MCSessionState.Connected:
            print("Connected: \(peerID.displayName)")
            log.info("Connected: \(peerID.displayName)")
            ipadConnectionStatuslbl.stringValue = "Connected"
            
        case MCSessionState.Connecting:
            print("Connecting: \(peerID.displayName)")
            log.info("Connecting: \(peerID.displayName)")
            ipadConnectionStatuslbl.stringValue = "Connecting.."
            
        case MCSessionState.NotConnected:
            print("Not Connected: \(peerID.displayName)")
            log.info("Not Connected: \(peerID.displayName)")
            ipadConnectionStatuslbl.stringValue = "Not Connected"
            disableiPADBtns()
            
            let ac: NSAlert = NSAlert()
            ac.messageText = "Unable to connect to the Peer Devices"
            ac.informativeText = "Connection with Device \(peerID.displayName) is lost"
            ac.alertStyle = NSAlertStyle.WarningAlertStyle
            ac.addButtonWithTitle("OK")
            
            let res = ac.runModal()
            if res == NSAlertFirstButtonReturn {
                log.info("Connection with Device \(peerID.displayName) is lost")
                
                return
                
            }
        }
    }
    
    //To receive Message on the other side
    func session(session: MCSession, didReceiveData data: NSData, fromPeer peerID: MCPeerID)
    {
        if let str = NSString(data: data, encoding: NSUTF8StringEncoding)  {
            dispatch_async(dispatch_get_main_queue()) { [unowned self] in
                log.info("Received String from iPAD: \(str as String)")
                self.setScreen(str as String)
            }
        }
    }

    //Function to communicate with MAC
    func sendMesg()
    {
        if(mcSession != nil){
            if mcSession.connectedPeers.count > 0 {
                // 2
                if !messg.isEmpty {
                    // 3
                    do {
                        try mcSession.sendData(messg.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)!, toPeers: mcSession.connectedPeers, withMode: MCSessionSendDataMode.Reliable)
                        log.info("String Sent from Mac: \(messg)")
                        print("###Message sent = \(messg)")
                    } catch let error as NSError {
                        
                        let ac: NSAlert = NSAlert()
                        ac.messageText = "Error while sending Message"
                        ac.informativeText = error.localizedDescription
                        ac.alertStyle = NSAlertStyle.WarningAlertStyle
                        ac.addButtonWithTitle("OK")
                        
                        let res = ac.runModal()
                        if res == NSAlertFirstButtonReturn {
                            log.info("Error while sending Message: \(error.localizedDescription)")
                            return
                        }
                    }
                }
            }
        }
    }
    
    func sendImage(img: NSImage) {
        
        print("Inside Send Image")
        if mcSession.connectedPeers.count > 0 {
            
            if let data = img.TIFFRepresentation {
                let imageRep = NSBitmapImageRep(data: data)
                let imageData = imageRep?.representationUsingType(NSBitmapImageFileType.NSPNGFileType, properties: [:])
                //do something with your PNG data here
                
                do {
                    try mcSession.sendData(imageData!, toPeers: mcSession.connectedPeers, withMode: .Reliable)
                    print("Image Sent")
                } catch let error as NSError {
                    let ac: NSAlert = NSAlert()
                    ac.messageText = "Error while sending Image"
                    ac.informativeText = error.localizedDescription
                    ac.alertStyle = NSAlertStyle.WarningAlertStyle
                    ac.addButtonWithTitle("OK")
                    
                    let res = ac.runModal()
                    if res == NSAlertFirstButtonReturn {
                        return
                    }
                    
                }
                
            }
        }
    }



}

