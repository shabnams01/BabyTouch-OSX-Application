//
//  Timer.swift
//  ic_v5Mac
//
//  Created by Shabnam Suresh on 2015-12-29.
//  Copyright © 2015 Shabnam Suresh. All rights reserved.
//

import Cocoa

class Timer: NSObject {
    
    var maxTime = 10
    var currentTime = 0
    var timerRunning = false
    var colorChage = false
    var warningReqd = false
    
    var timer = NSTimer()
    
    func startTimer(){
        
        if !timerRunning {
            timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("CounterForTimer"), userInfo: nil, repeats: true)
            timerRunning = true
        }

    }
    
    func stopTimer(){
        if timerRunning {
            timer.invalidate()
            timerRunning = false
        }
        
    }
    
    func resetTimer() -> Int{
        currentTime = 0
        return currentTime
        
    }
    
    func CounterForTimer() -> Int{
        currentTime += 1
        return currentTime
    }
    
    func getColorChangeFlag() -> Bool{
        return colorChage
    }
    
    func setColorChangeFlag(flag : Bool){
        colorChage = flag
    }
    
    func setWarning(flag : Bool) {
        warningReqd = flag
    }
    
    func getWarningFlag() -> Bool{
        return warningReqd
    }
    
    

    func getCurrentTime() -> Int{
        return currentTime
    }
    
    func getMaximumTime() -> Int{
        return maxTime
    }
    
    func setMaximumTime(value : Int){
        maxTime = value
        
    }

}
