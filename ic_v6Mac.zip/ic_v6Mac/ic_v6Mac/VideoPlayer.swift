//
//  VideoPlayer.swift
//  videoTesting
//
//  Created by Shabnam Suresh on 2016-04-29.
//  Copyright © 2016 Shabnam Suresh. All rights reserved.
//

import Cocoa
import AVKit
import AVFoundation

class VideoPlayer: NSObject {
    
    var player : AVPlayer! = nil
    var avplayerview: AVPlayerView! = nil
    var videoFinishedPlaying : Bool! = nil
    
    var videoImageView: NSImageView! = nil
    
    func getVidImageView()-> NSImageView{
        return videoImageView
    }
    
    func setVidImageView(i : NSImageView){
        videoImageView = i
    }
    
    func getVideoFinshedPlaying()-> Bool{
        return videoFinishedPlaying
    }
    
    func setVideoFinshedPlaying(b : Bool){
        videoFinishedPlaying = b
    }
    
    func getAVPlayer() -> AVPlayer{
        return player
    }
    
    func setAVPlayer( p : AVPlayer){
        player = p
    }
    
    
    func getAVPlayerView() -> AVPlayerView{
        return avplayerview
    }
    
    func setAVPlayerView(avp : AVPlayerView) {
        avplayerview = avp
    }
    
   
    func PlayVideo(){
        print("Inside Play video")
        
        
        if(fileURL != nil)
        {
            //hide the empty player View 
            // this has been implemented to show a black screen one the video finish playing
            emptyPlayerObject.avplayerview.hidden = true
            //Varable that tracks whether the video has completed or not
            
            player = AVPlayer(URL: fileURL)
            avplayerview.player = player
            player.play()
            
            NSNotificationCenter.defaultCenter().addObserver(self,
                selector: #selector(VideoPlayer.playerDidFinishPlaying(_:)),
                name: AVPlayerItemDidPlayToEndTimeNotification, object: player.currentItem)
            
            //To update the player view based on the window size
            avplayerview.videoGravity = AVLayerVideoGravityResizeAspectFill
            //To show the full Screen toggle button
            avplayerview.showsFullScreenToggleButton = true
           
        }
        
        
    }
    
    
    
    
    func playerDidFinishPlaying(note: NSNotification) {
        
        if(buttonId == "X"){
            print("Video Finished playing Normally")
            videoPlayerObject.videoFinishedPlaying = true
            emptyPlayerObject.avplayerview.hidden = false
        }

        //To hidde the attention grabber video 
        if(buttonId == "AG"){
            attnGrabberVideoPlayerObject.avplayerview.hidden = true
            
            buttonId = "X"
            if(!videoPlayerObject.videoFinishedPlaying)
            {
                print("Video HAS NOT Finished playing")
                emptyPlayerObject.avplayerview.hidden = true
            }
            else
            {
                print("Video Finished playing")
                emptyPlayerObject.avplayerview.hidden = false
            }
            
        }
        
        
    }
    
    
    func PauseVideo(){
        
        videoPlayerObject.videoFinishedPlaying = false
    
        if(player != nil){
            player.pause()
        }
        
    }
    
    func ResumeVideo(){
       
        if(player != nil){
            player.play()
        }
        
    }

}
