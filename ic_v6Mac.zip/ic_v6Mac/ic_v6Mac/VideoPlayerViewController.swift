//
//  VideoPlayerViewController.swift
//  videoTesting
//
//  Created by Shabnam Suresh on 2016-04-28.
//  Copyright © 2016 Shabnam Suresh. All rights reserved.
//

import Cocoa
import AVKit
import AVFoundation



class VideoPlayerViewController: NSViewController, NSWindowDelegate{
    
    
    @IBOutlet weak internal var attnGrabberAVPlayerView: AVPlayerView!
    @IBOutlet weak var avPlayerView: AVPlayerView!
    @IBOutlet weak var emptyPlayerView: AVPlayerView!
    
    @IBOutlet weak var startupPlayerView: AVPlayerView!
    
    
    var player = AVPlayer()
    var attnGrabberPlayer = AVPlayer()
    var emptyPlayer = AVPlayer()
    var startupPlayer = AVPlayer()
    
    //Function that is called everytime the view is loaded
    override func viewWillAppear() {
        //To get access on the new window close button
        
        videoPlayerObject.setAVPlayer(player)
        videoPlayerObject.setAVPlayerView(avPlayerView)
        
        
        
        //videoPlayerObject.PlayVideo()
        hideAttnGrabberPlayerView()
        
        
        attnGrabberVideoPlayerObject.setAVPlayer(attnGrabberPlayer)
        attnGrabberVideoPlayerObject.setAVPlayerView(attnGrabberAVPlayerView)
        
        emptyPlayerObject.setAVPlayer(emptyPlayer)
        emptyPlayerObject.setAVPlayerView(emptyPlayerView)
        
        startupPlayerObject.setAVPlayer(startupPlayer)
        startupPlayerObject.setAVPlayerView(startupPlayerView)
        fileURL = NSURL(fileURLWithPath:"/Users/shabnam_suresh/Desktop/UBCProject/Xcode/ic_v6Mac/ic_v6Mac/startVideoPlayer.mov")
        
        if(startupPlayerObject.player != nil)
        {
            startupPlayerObject.PlayVideo()
        }
        
        self.view.window?.delegate = self
        
        self.view.window?.title = ""
        self.view.window?.styleMask |= NSFullSizeContentViewWindowMask
        self.view.window?.titlebarAppearsTransparent = true
        
        self.view.window?.standardWindowButton(NSWindowButton.ZoomButton)!.hidden = true
        self.view.window?.standardWindowButton(NSWindowButton.MiniaturizeButton)!.hidden = true
        //self.view.window?.standardWindowButton(NSWindowButton.CloseButton)!.enabled = false
        
        //Not working
        //self.view.window?.titleVisibility = NSWindowTitleVisibility.Hidden
        self.view.window?.movableByWindowBackground = true
        
        
        
        
    }
    
    
    
    func hideAttnGrabberPlayerView(){
        attnGrabberAVPlayerView.hidden = true
    }
    
    /*
    func showAttnGrabberPlayerView(){
        
        attnGrabberAVPlayerView.hidden = false
    }
    */
    
    
    func windowShouldClose(sender: AnyObject) -> Bool {
        print("Window closed")
        if(videoPlayerObject.player != nil)
        {
            videoPlayerObject.PauseVideo()
            
            
        }
        if(attnGrabberVideoPlayerObject.player != nil)
        {
            attnGrabberVideoPlayerObject.PauseVideo()
           
        }
        
        print("External Screen Window has been closed")
        //To access the controls on the main window
        let mainVC = NSApplication.sharedApplication().mainWindow?.contentViewController as? ViewController
        mainVC?.disableExternalScreenBtns()
        

        return true
    }
    
    
    
}
